module.exports = {
    webhookPush: require('./controllers/push.controller'),
    webhookPR: require('./controllers/pr.controller')
}